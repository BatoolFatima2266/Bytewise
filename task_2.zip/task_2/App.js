import React,{useState} from 'react';
import {Text,View,ScrollView,TextInput,Button,String} from 'react-native';
const myApp=()=>{
   const [input,setInput]=useState('Hello');
  
  function submit(){
   setInput('hi');
  }
  return(
    <ScrollView>
    <View> 
     <Text style={{textAlign:"center"}}>{input}</Text>
    <Button title="click" onPress={submit}></Button>
    </View>
    </ScrollView>
  );
}
export default myApp;
