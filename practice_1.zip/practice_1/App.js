import {React} from "react";
import {View, Text, Image, ScrollView, TextInput} from "react-native";
const corecomponents=()=>{
return(
  <ScrollView style={{alignItems:"center",justifyContent:"center"}}>
  <Text style={{textAlign:"center",paddingBottom:"10px",}}>Cat Image</Text>
  <View style={{paddingBottom:"10px",}}>
  <Image source={{
    uri:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0k2A_Hc9fq0GuQMt7i5hnJmY3m-2JfULTyQ&s',
  }}
  style={{width: 200, height: 200,alignItems:"center",justifyContent:"center",paddingBottom:"10px",}}></Image>
  </View>
  <TextInput style={{height: 20,borderColor:"black",borderWidth:2}} defaultValue="e.g: Mili"></TextInput>
  </ScrollView>
);
};
export default corecomponents;
